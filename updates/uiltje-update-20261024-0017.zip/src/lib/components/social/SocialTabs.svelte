<script lang="ts">
	import { page } from '$app/state';
	import Icon, { type IconName } from '../ui/Icon.svelte';

	// Vrienden, Ranglijst and Uitdagingen are one area: the same tabs on top of each of the three pages.
	const TABS: { href: string; label: string; icon: IconName; prefixes: string[] }[] = [
		{ href: '/friends', label: 'Vrienden', icon: 'users', prefixes: [] },
		{ href: '/leaderboard', label: 'Ranglijst', icon: 'trophy', prefixes: [] },
		{ href: '/uitdagingen', label: 'Uitdagingen', icon: 'flame', prefixes: ['/uitdaging/'] }
	];
	const active = (tab: (typeof TABS)[number]) => [tab.href, ...tab.prefixes].some((p) => page.url.pathname === p || page.url.pathname.startsWith(p.endsWith('/') ? p : `${p}/`));
</script>

<nav aria-label="Vrienden" class="flex flex-wrap gap-2">
	{#each TABS as tab (tab.href)}
		<a
			href={tab.href}
			aria-current={active(tab) ? 'page' : undefined}
			class={[
				'inline-flex min-h-10 items-center gap-2 rounded-full border-[1.5px] px-4 font-heading font-semibold transition-colors',
				active(tab) ? 'border-primary bg-primary-soft text-primary-text' : 'border-border bg-surface text-text-muted hover:bg-surface-2 hover:text-text'
			]}
		>
			<Icon name={tab.icon} size={18} /> {tab.label}
		</a>
	{/each}
</nav>
