import { redirect } from '@sveltejs/kit';
import type { PageLoad } from './$types';

// The question bank moved into /review.
export const load: PageLoad = () => redirect(307, '/review?tab=vragen');
